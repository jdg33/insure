
export const INSURANCE_KEYWORDS = [
  'insurance',
  'indemnity',
  'indemnify',
  'indemnification',
  'liability',
  'coverage',
  'certificate of insurance',
  'insured party',
  'additional insured',
  'policy limit',
  'policy limits',
  'risk management',
  'hold harmless',
  'subrogation',
  'underwriter',
  'premium',
];
